
if you got an error for logo pic , 

go to assests and, copy the path you have of logo. 

and paste it in these : 

1 - signup 
2- sign in 
3- homescreen 


paste the path of logo in assests , in url place of your device.
